from .structures import Table, TableOperator
from .enums import Order, Type